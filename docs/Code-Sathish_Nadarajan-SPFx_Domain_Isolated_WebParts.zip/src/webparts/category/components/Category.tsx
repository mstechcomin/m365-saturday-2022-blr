import * as React from 'react';
import styles from './Category.module.scss';
import { ICategoryProps } from './ICategoryProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { HttpClient, IHttpClientOptions, HttpClientResponse } from '@microsoft/sp-http';

export default class Category extends React.Component<ICategoryProps, {}> {

  public async componentDidMount() {
    try {

      let apiUrl = `https://sambotapi.azurewebsites.net/api/Category/GetAllCategory`;

            const requestHeaders: Headers = new Headers();
            requestHeaders.append('Accept', '*/*');
            requestHeaders.append('X-ClientTag', 'NONISV|Microsoft|c7e68b69-2688-4d00-8e6c-be0e8a3e7950/2.0.0.1');


            const httpClientOptions: IHttpClientOptions = {
                headers: requestHeaders,
                method: "GET",
                mode: "cors",

            };



            let temp = await this.props.categoriesHttpclient.get(apiUrl, HttpClient.configurations.v1, httpClientOptions);
       
    }
    catch (error) {
       
    }
  }

  public render(): React.ReactElement<ICategoryProps> {
    const {
      description,
      isDarkTheme,
      environmentMessage,
      hasTeamsContext,
      userDisplayName,
      categoriesHttpclient
    } = this.props;

    

    return (
      <div>
      <section className={`${styles.category} ${hasTeamsContext ? styles.teams : ''}`}>
        My Test WebPart 1
      </section>
      </div>
    );
  }
}
