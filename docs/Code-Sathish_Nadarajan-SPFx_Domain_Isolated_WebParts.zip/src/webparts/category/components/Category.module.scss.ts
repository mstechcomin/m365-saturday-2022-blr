/* tslint:disable */
require("./Category.module.css");
const styles = {
  category: 'category_0f97c76b',
  teams: 'teams_0f97c76b',
  welcome: 'welcome_0f97c76b',
  welcomeImage: 'welcomeImage_0f97c76b',
  links: 'links_0f97c76b'
};

export default styles;
/* tslint:enable */