
import ICategoriesWorker from './ICategoriesWorker';

import { HttpClient, IHttpClientOptions, HttpClientResponse } from '@microsoft/sp-http';



export default class CategoriesWorker implements ICategoriesWorker {

    private httpClient: HttpClient;
     

    public getAllCategories = async (props: any, sambotAPIURL: string): Promise<any> => {
        try {
             

            let apiUrl = `${sambotAPIURL}/api/Category/GetAllCategory`;

            const requestHeaders: Headers = new Headers();
            requestHeaders.append('Accept', '*/*');
            requestHeaders.append('X-ClientTag', 'NONISV|Microsoft|c7e68b69-2688-4d00-8e6c-be0e8a3e7950/2.0.0.1');


            const httpClientOptions: IHttpClientOptions = {
                headers: requestHeaders,
                method: "GET",
                mode: "cors",

            };



            let temp = await props.get(apiUrl, HttpClient.configurations.v1, httpClientOptions);
            return temp.json();
        }
        catch (error) {
             
        }
    }


     
}