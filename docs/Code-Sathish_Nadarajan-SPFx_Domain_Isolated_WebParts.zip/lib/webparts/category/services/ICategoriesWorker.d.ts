interface ICategoriesWorker {
    getAllCategories(props: any, sambotAPIURL: string): Promise<any>;
}
export default ICategoriesWorker;
//# sourceMappingURL=ICategoriesWorker.d.ts.map