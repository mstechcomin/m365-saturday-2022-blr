import ICategoriesWorker from './ICategoriesWorker';
export default class CategoriesWorker implements ICategoriesWorker {
    private httpClient;
    getAllCategories: (props: any, sambotAPIURL: string) => Promise<any>;
}
//# sourceMappingURL=CategoriesWorker.d.ts.map