import * as React from 'react';
import { ICategoryProps } from './ICategoryProps';
export default class Category extends React.Component<ICategoryProps, {}> {
    componentDidMount(): Promise<void>;
    render(): React.ReactElement<ICategoryProps>;
}
//# sourceMappingURL=Category.d.ts.map