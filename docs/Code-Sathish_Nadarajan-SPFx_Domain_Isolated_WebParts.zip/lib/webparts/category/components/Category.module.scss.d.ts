declare const styles: {
    category: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Category.module.scss.d.ts.map