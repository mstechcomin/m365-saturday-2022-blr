import { HttpClient } from "@microsoft/sp-http";
export interface ICategoryProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    categoriesHttpclient: HttpClient;
}
//# sourceMappingURL=ICategoryProps.d.ts.map